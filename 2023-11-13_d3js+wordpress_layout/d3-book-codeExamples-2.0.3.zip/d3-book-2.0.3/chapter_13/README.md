
### ev_sales_data.csv

This file was derived from data compiled by Yan (Joann) Zhou at Argonne National Laboratory, U.S. Department of Energy, and published by the DOE’s Office of Public Affairs, accompanied by a chart by Daniel Wood, Data Visualization and Cartographic Specialist in that office.

Notes: Sales from the second quarter of 2013 for Tesla Model S are based off of estimates provided by the Hybrid Market Dashboard.  Data last updated 1/20/15.

“Electric and Hybrid Electric Vehicle Sales: December 2010 - June 2013”

As accessed on March 14, 2017 from:
https://energy.gov/sites/prod/files/2013/07/f2/062010-092013_EV_HEV%20Sales.xlsx

Source pages and more info:

- https://energy.gov/downloads/electric-and-hybrid-electric-vehicle-sales-december-2010-june-2013
- https://energy.gov/articles/visualizing-electric-vehicle-sales
