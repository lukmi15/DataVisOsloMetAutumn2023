let bgImgs = [];
let nextWaiting = [];
let prevWaiting = [];
let currentImg = 0;
let prevImg = 0;//for resetting opacity to 0 after fade
bgImgs = document.getElementsByClassName('bgimage');

var nextImgPos = 0;
for (var i = 1;i < bgImgs.length;i++){
	bgImgs[i].style.opacity = 0;
	
}
//prevs and nexts arrays contains last swoosh element before and first swoosh after each Background image. Each element in these arrays are there to trigger background image changes
//These are to be monitored by the Intersection Observer API to trigger the background changes
//trigger an image change 
//one swoosh, many sweesh
let sweesh = [];
sweesh = document.getElementsByClassName("swoosh");
for (var i = 0;i < sweesh.length; i++){
    sweesh[i].swooshId = i;
}
let allElements = [];

//AUG 23 NOTE:
//The observer must run on all sweesh and deispatch scrollNext/Prev events
//Id's on all sweesh are probably necessary
let nexts = [];//This solves image swapping
let prevs = [];//Simply run the observer on next and prev
console.log(sweesh[7]);

//console.log(sweesh[7].getBoundingClientRect().top);
var moreBgs = true;
var newId = 0;
var currentBg = 0;//Variable for storing the index of the currently visible background
bgImgs[0].style.position = 'fixed';
bgImgs[0].style.backgroundSize = 'cover';
bgImgs[0].class = "activeBackground";
for (var i = 0; i < bgImgs.length; i++){
	var isw = 0;
	if (moreBgs && bgImgs[i + 1]){
        //Loop to get actual displayed order of elements and positions, no assumptions!
		while (sweesh[isw].getBoundingClientRect().top < bgImgs[i + 1].getBoundingClientRect().top){
			isw++
		}
		if (isw > 3){
			prevs.push(isw-3);
			
			prevWaiting.push(false);
		} else 
			if (isw > 2){
			prevs.push(isw-2);
			prevWaiting.push(false);
		} else if (isw > 1){
			prevs.push(isw-1);
			prevWaiting.push(false);		
		} 
		nexts.push(isw-1);
		sweesh[isw-1].myId = newId;
        console.log("Sweesh id: "+sweesh[isw-1].myId);
		if (sweesh[isw-1].style.height < '100px'){
			sweesh[isw-1].style.height = '100px';
			sweesh[isw-1].style.borderStyle = "solid";
		}
		newId++;
		bgImgs[i + 1].style.position = 'fixed';
		//console.log("Img+1 top: "+ bgImgs[i + 1].getBoundingClientRect().top);
		//console.log("swoosh top: "+ sweesh[isw].getBoundingClientRect().top);
	} else {
		moreBgs = false;
	}
}
console.log("NEXTS:");
console.log(nexts);
console.log("nextWaiting");
console.log(nextWaiting);
console.log("prevs:");
console.log(prevs);

/*
function callbackFunction(entries) { // array of observing elements
    entries.forEach( entry => {
        // The logic to apply for each entry 
           if(entry.isIntersecting) {
			  
               //entry.classList.add("visibleEffect");  //visibleEffect is a css class which adds effects on visibility
           } else {
               //entry.classList.remove("visibleEffect");  
           }  
    })
}
*/

var intersectionRoot = document.querySelector('#ancestor');
var observer = new IntersectionObserver(function(entries) {
    // anonymous callback function
    // do something with the changes (callback)
    //console.log("TOP AND BOTTOM:");
    console.log(entries);
    //console.log(entries[0].boundingClientRect.top);
	//console.log(entries[0].boundingClientRect.bottom);
	//console.log(entries[0].target.myId);
    //entries[0].target.myId
	if ( (entries[0].boundingClientRect.top < 0)){
    //if ((entries[0].target.myId) && (entries[0].boundingClientRect.top < 0)){
        console.log("vvvvv");
		if ((Number.isInteger(entries[0].target.myId)) && (currentImg != (entries[0].target.myId + 1))){
            //if (Number.isInteger(entries[0].target.myId)){
                var newImg = entries[0].target.myId + 1;
                
               
                //console.log("SWAP IMAGE +1 : newImg: "+newImg);
                swapImg(newImg);
                console.log("BILDEBYTTE FORRIGE");
            //} else {
                //console.log("++ uten myId. scrollNext her??")
            //}
		} else {
            console.log("TARGET: CHECK FOR SWOOSH ID:");
            console.log(entries[0].target.swooshId);
        }
	} else {
		//console.log("currentImg : "+currentImg+" entries[0].target.myId : "+entries[0].target.myId);
        console.log(entries[0].boundingClientRect.top);
        //console.log("^^^^^^");
		if ((Number.isInteger(entries[0].target.myId)) && (currentImg != (entries[0].target.myId))){
        //if ((entries[0].target.myId) && (currentImg != (entries[0].target.myId))){
            //if (Number.isInteger(entries[0].target.myId)){
                var newImg = entries[0].target.myId;
               console.log("BILDEBYTTE NESTE");
                swapImg(newImg);
            //} else {
                //console.log("-- uten Id. scrollPrev?");
            //}
		} else {
            console.log("TARGET: FRA BUNNEN:");
            console.log(entries[0].target.swooshId);
            console.log(document.getElementsByClassName('activeBackground'));
            console.log(document.getElementsByClassName('activeBackground').contentWindow);
            //document.getElementsByClassName('activeBackground').contentWindow.scrollNext();
        }
	}
}, 
    {  //anonymous options object
      //root: intersectionRoot,
      rootMargin: '0px',
      threshold: 1
    }
);
//sweesh[nexts[0]].myId = 0;
console.log(sweesh);
var targetElement = sweesh[nexts[0]];
/*
console.log("TARGET ELEMENT:");
console.log("nexts:");
console.log(nexts);
console.log("PREVS : ");
console.log(prevs);
console.log(sweesh[nexts[0]]);
*/
//start observing the target node for intersections
/*
console.log("SWEESH:");
console.log(sweesh);
console.log("NEXTS");
console.log(nexts);

for (var i = 0; i < nexts.length; i++){
	observer.observe(sweesh[nexts[i]]);
}
*/



//Try this Cowboy!

console.log("Be a Cowboy!");
for (var i = 0; i < sweesh.length; i++){
	observer.observe(sweesh[i]);
}



function turnOffAlpha(){
	//console.log("ALPHA OFF");
	bgImgs[prevImg].style.opacity = 0;
}

function swapImg(showImg){
	//console.log("Z-Index :");
	bgImgs[showImg].style.opacity = 1;
	bgImgs[currentImg].style.zIndex = 1000;
	bgImgs[showImg].style.zIndex = 1010;
	bgImgs[currentImg].style.opacity = 1;
    console.log(bgImgs[showImg]);
    bgImgs[currentImg].class = "hiddenBackground";
    bgImgs[showImg].class = "activeBackground";

	//bgImgs[currentImg].classList.remove("fadeIn");
	//bgImgs[showImg].classList.add("fadeIn");
	prevImg = currentImg;
	currentImg = showImg;
	setTimeout(turnOffAlpha, 500);
}

//onVisible(sweesh[nexts[0]], () => nextImage());

/*
function intersectionCallback(entries) {
  entries.forEach((entry) => {
    entry.target.style.opacity = entry.intersectionRatio;
  });
}
intersectionCallback(swaps);



function swapImg(){
	//elements[1].style.opacity = 1;
}
//console.log("Bounding rectangle:");
//console.log(elements[1].getBoundingClientRect());
//console.log("elements length:");
//console.log(elements.length);
//var contentDiv = document.getElementsByClassName('entry-content');

/*
if (contentDiv.Node.hasChildNodes()){
	console.log("Meeeeh");
	  let children = contentDiv.Node.childNodes;
		//console.log(children);
} else {
	console.log("Njetz!");
}
*/





