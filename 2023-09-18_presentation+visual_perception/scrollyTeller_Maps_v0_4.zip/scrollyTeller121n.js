let bgImgs = [];
let nextWaiting = [];
let prevWaiting = [];
let currentImg = 0;
let prevImg = 0;//for resetting opacity to 0 after fade
bgImgs = document.getElementsByClassName('bgimage');

var nextImgPos = 0;
for (var i = 0;i < bgImgs.length;i++){
	bgImgs[i].style.opacity = 0;
	
}
console.log(bgImgs);
//These are to be monitored by the Intersection Observer API to trigger the background changes
//trigger an image change 
//one swoosh, many sweesh
let sweesh = [];
let bgrRefs = [];//This will store bg id's in a paralell array to sweesh for easy swaps on runtime
let sweeshIds = [];//Ok, noe more. Maybe uneccessasry but helps see data during dev time.

sweesh = document.getElementsByClassName("swoosh");
var currentSwoosh = 0;
var expectedSwoosh = 1; //Most users scroll down most of the time. Test against this to see if the uyser scrolls up
var previousSwoosh = 0; // WHere the user is coming from. Used to decide scroll direction
for (var i = 0;i < sweesh.length; i++){
    sweesh[i].swooshId = i;
    sweesh[i].hasPassed = false;
}
let allElements = [];
console.log(sweesh);

//AUG 23 NOTE:
//The observer must run on all sweesh and dispatch scrollNext/Prev events
//Id's on all sweesh are probably necessary
let nexts = [];//This solves image swapping
let prevs = [];//Simply run the observer on next and prev
console.log(sweesh[7]);

//console.log(sweesh[7].getBoundingClientRect().top);
var moreBgs = true;
//var newId = 0;
//var currentBg = 0;//Variable for storing the index of the currently visible background
bgImgs[0].style.position = 'fixed';
bgImgs[0].style.backgroundSize = 'cover';
bgImgs[0].class = "activeBackground";
var scrollDown = true;
var isw = 0;
var stepCounter = 0;
var stepCounts = [];
for (var i = 0; i < bgImgs.length; i++){
    stepCounter = 0;
    if (bgImgs[i+1]){
        
        while (sweesh[isw].getBoundingClientRect().top < bgImgs[i+1].getBoundingClientRect().top){
            if (sweesh[isw].style.height < '100px'){
                //sweesh[isw].style.height = '100px';
                sweesh[isw].style.borderStyle = "solid";
            }
            stepCounts.push(stepCounter);
            stepCounter++;
			isw++
            console.log(i);
            bgrRefs.push(parseFloat(i));
        }
    } else {
        while (isw < sweesh.length){
            if (sweesh[isw].style.height < '100px'){
                //sweesh[isw].style.height = '100px';
                sweesh[isw].style.borderStyle = "solid";
            }
            stepCounts.push(stepCounter);
            stepCounter++;
			isw++
            console.log(i);
            bgrRefs.push(parseFloat(i));
        }

    }
    bgImgs[i].style.position = 'fixed';
}

console.log(stepCounts);
/*
for (var i = 0; i < bgImgs.length; i++){
	//bgrRefs.push(parseFloat(i));
	if (moreBgs && bgImgs[i + 1]){
        //Loop to get actual displayed order of elements and positions, no assumptions!
		while (sweesh[isw].getBoundingClientRect().top < bgImgs[i].getBoundingClientRect().top){
            if (sweesh[isw].style.height < '100px'){
                sweesh[isw].style.height = '100px';
                sweesh[isw].style.borderStyle = "solid";
            }
			isw++
            console.log(i);
            bgrRefs.push(parseFloat(i-1));
		}
        
		
		
		//sweesh[isw-1].myId = newId;
        //sweeshIds.push(newId);
        //console.log("Sweesh id: "+sweesh[isw-1].myId);
		
		//newId++;
		bgImgs[i].style.position = 'fixed';
		//console.log("Img+1 top: "+ bgImgs[i + 1].getBoundingClientRect().top);
		//console.log("swoosh top: "+ sweesh[isw].getBoundingClientRect().top);
	} else {
		//moreBgs = false;
	}
    //bgrRefs.push(parseFloat(i));
}
*/
console.log("SWEESH AND BGREFS:");
console.log(sweeshIds);
console.log(bgrRefs);
/*
console.log("NEXTS:");
console.log(nexts);
console.log("nextWaiting");
console.log(nextWaiting);
console.log("prevs:");
console.log(prevs);
*/



var intersectionRoot = document.querySelector('#primary');
var observer = new IntersectionObserver(function(entries) {
    
    //console.log(entries);
    //console.log(entries[0].target.myId);
    //entries[0].target.myId
	
		//console.log("currentImg : "+currentImg+" entries[0].target.myId : "+entries[0].target.myId);
        //if (entries[0].boundingClientRect.top > 100){
            //console.log(entries[0].intersectionRatio);
            //console.log(entries[0].boundingClientRect.top);
            console.log(entries[0].boundingClientRect.y);
            console.log(entries[0].target);
            console.log("ROTEN TIL ALT:");
            console.log(intersectionRoot);
            //console.log(entries[0].rootBounds);
        //}
        //console.log("^^^^^^");
		
        //var newImg = entries[0].target.myId;

        newImg = bgrRefs[entries[0].target.swooshId];
        currentSwoosh = entries[0].target.swooshId;
        entries[0].target.hasPassed = true;
        //console.log("currentImg :"+currentImg);
        //console.log("newImg : "+newImg);
        //if (document.getElementsByClassName('activeBackground').item(0)){
            console.log("Bazoooka Jim! currentSwoosh : "+currentSwoosh);
            //console.log(document.getElementsByClassName('activeBackground'));
            document.getElementsByClassName('bgimage').item(0).contentWindow.goStep(stepCounts[currentSwoosh]);
        //}

        if (currentImg != newImg){
            swapImg(newImg);
        }  
        /*
        if ((bgrRefs[currentSwoosh] != bgrRefs[entries[0].target.swooshId])&& (entries[0].boundingClientRect.top > 100) && (! entries[0].target.hasPassed)){
            //console.log("ULIKE Barn er fint");
            newImg = bgrRefs[entries[0].target.swooshId];
            currentSwoosh = entries[0].target.swooshId;
            entries[0].target.hasPassed = true;
            //console.log("currentImg :"+currentImg);
            //console.log("newImg : "+newImg);
            if (currentImg != newImg){
                swapImg(newImg);
            }        
        } else if ((bgrRefs[currentSwoosh] == bgrRefs[entries[0].target.swooshId])&& (entries[0].boundingClientRect.top > 100) && (entries[0].target.swooshId <= currentSwoosh)){
            //console.log("Like barn er en pest og en plage!");
            currentSwoosh = entries[0].target.swooshId;
            if (entries[0].target.hasPassed){
                //console.log("mindre enn eller lik");
                newImg = bgrRefs[(entries[0].target.swooshId -1)];
                entries[0].target.hasPassed = false;
                scrollDown = false;
            } else if (! entries[0].target.hasPassed){
                //console.log("Større enn");
                newImg = bgrRefs[(entries[0].target.swooshId)];
                entries[0].target.hasPassed = true;
                //scrollDown = true;
            }
            //console.log("currentImg :"+currentImg);
            //console.log("newImg : "+newImg);
            if (currentImg != newImg){
                swapImg(newImg);
            }
            

        }
       */
	
}, 
    {  //anonymous options object
      //root: intersectionRoot,
      //scrollMargin: '35%',
      rootMargin: '-45% 0% -45% 0%',
      //rootMargin: '0px',
      threshold: 0
    }
);
//sweesh[nexts[0]].myId = 0;
console.log(sweesh);
var targetElement = sweesh[nexts[0]];







function turnOffAlpha(){
	//console.log("ALPHA OFF");
	bgImgs[prevImg].style.opacity = 0;
}

function swapImg(showImg){
	console.log("current : "+currentImg+"show :"+showImg);
	bgImgs[showImg].style.opacity = 1;
	bgImgs[currentImg].style.zIndex = 1000;
	bgImgs[showImg].style.zIndex = 1010;
	bgImgs[currentImg].style.opacity = 1;
    console.log(bgImgs[showImg]);
    bgImgs[currentImg].className = "hiddenBackground";
    bgImgs[showImg].className = "activeBackground";

	//bgImgs[currentImg].classList.remove("fadeIn");
	//bgImgs[showImg].classList.add("fadeIn");
	prevImg = currentImg;
	currentImg = showImg;
	setTimeout(turnOffAlpha, 500);
}

bgImgs[currentImg].style.zIndex = 1000;
bgImgs[currentImg].style.opacity = 1;
bgImgs[currentImg].className = "bgimage";

for (var i = 0; i < sweesh.length; i++){
    console.log("boing");
	observer.observe(sweesh[i]);
}








