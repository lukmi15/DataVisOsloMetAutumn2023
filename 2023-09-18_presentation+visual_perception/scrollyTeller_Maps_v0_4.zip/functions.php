<?php
/**
 * GeneratePress child theme functions and definitions.
 *
 * Add your custom PHP in this file.
 * Only edit this file if you have direct access to it on your server (to fix errors if they happen).
 */

 function scrollyteller_js() {
    wp_enqueue_script( 'theme_js', get_stylesheet_directory_uri() . '/scrollyTeller121n.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'scrollyteller_js' );
